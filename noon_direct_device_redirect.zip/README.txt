نسخة التحويل المباشر:
- iPhone/iPad -> App Store
- Android/Samsung -> Google Play
- لا توجد واجهة أو أزرار للمستخدم.
- ارفع index.html و .nojekyll إلى GitHub Pages.
- استخدم رابط GitHub Pages الناتج داخل QR.
